<div class="modal fade" id="add" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Add</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group row">
                        <label class="col-lg-3" for="">Sekolah</label>
                        <div class="col-lg-9">

                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-lg-3" for="">Tahun Ajaran</label>
                        <div class="col-lg-9">
                            <input type="text" class="form-control" placeholder="2022/2023">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3" for="">Waktu Mulai</label>
                        <div class="col-lg-9">
                            <input type="date" class="form-control mb-1" placeholder="2022/2023">
                            <input type="time" class="form-control" placeholder="2022/2023">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3" for="">Waktu Akhir</label>
                        <div class="col-lg-9">
                            <input type="date" class="form-control mb-1" placeholder="2022/2023">
                            <input type="time" class="form-control" placeholder="2022/2023">
                        </div>
                    </div>

                </div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
                    <button class="btn btn-primary">Save</button>
                </div>
            </div>
        </div>
    </div>